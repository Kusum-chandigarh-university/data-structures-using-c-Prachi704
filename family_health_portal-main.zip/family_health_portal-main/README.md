PROJECT MADE USING FLASK FRAMEWORK 
access site front end from 
link given below 
https://prachi17.pythonanywhere.com
